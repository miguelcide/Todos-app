const express = require("express");
const app = express();
const path = require("path");
const session = require("express-session");

app.set("views", path.join(__dirname, "views"));
app.set("view engine", "ejs");

app.use(express.static(path.join(__dirname, "public")));

app.use(
  express.urlencoded({
    extended: true,
  })
);

app.use(
  session({
    secret: "exam",
    cookie: { maxAge: 60000 },
    saveUninitialized: false,
  })
);

app.get("/", (req, res) => {
  res.render("home");
});

// Home Router
const homeRouter = require("./routes/home.routes");
app.use("/home", homeRouter);


let myTodos = 0;
let allTodos = 0;




const PORT = 8080;
app.listen(PORT, () => {
  console.log(`Listening on port ${PORT}!`);
});
